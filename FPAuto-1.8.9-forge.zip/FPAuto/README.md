# FPAuto (Forge 1.8.9) — for your own/private server use

Build: install JDK 8, then in this folder run
  gradlew setupDecompWorkspace build     (or `gradle ...` with Gradle 2.14)
Jar appears in build/libs/. Drop it in .minecraft/mods (Forge 1.8.9).

Keys: Right Shift = GUI, K = stop everything.
Setup: put weapon in hotbar slot 1, heal item slot 2, fishing rod slot 3 (change in Config.java).
Custom slayer: edit the last row of SLAYER_KEYWORDS in Config.java (boss name first, then mob keywords).
