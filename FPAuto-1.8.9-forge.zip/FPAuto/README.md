# FPAuto 1.1 (Forge 1.8.9) — private server use

Keys: Right Shift = GUI, G = toggle Auto Slayer, K = stop everything.
Hotbar defaults: weapon slot 1, heal item slot 2, rod slot 3.
Targets box: comma separated, left = highest priority (e.g. special,zealot,enderman).
Pickup box: item names to walk to after kills (e.g. Summoning Eye).
