package com.fpauto;

import net.minecraft.client.Minecraft;

import java.io.*;
import java.util.Properties;

public class Config {
    public static boolean autoFish = false;
    public static boolean autoSlayer = false;
    public static boolean autoHeal = true;
    public static boolean autoPickup = true;
    public static boolean showPath = true;
    public static boolean showHud = true;

    // Presets only fill the Targets box. Order in the box = priority (left is highest).
    public static final String[] PRESET_NAMES = {
        "Enderman + Special Zealot", "Revenant (Zombie)", "Tarantula (Spider)",
        "Sven (Wolf)", "Inferno (Blaze)", "Riftstalker (Vampire)", "Custom (keep my text)"
    };
    public static final String[] PRESET_TARGETS = {
        "special,zealot,voidgloom,enderman",
        "revenant horror,revenant,zombie",
        "tarantula broodfather,tarantula,spider",
        "sven packmaster,sven,wolf",
        "inferno demonlord,inferno,blaze",
        "bloodfiend,vampire",
        ""
    };
    public static int presetIndex = 0;

    public static String targets = PRESET_TARGETS[0];
    public static String pickupItems = "Summoning Eye";

    public static float healPercent = 0.5f;
    public static int weaponSlot = 0;   // hotbar 0-8
    public static int healSlot = 1;
    public static int rodSlot = 2;

    public static int recastDelay = 12;
    public static int attackDelay = 4;
    public static double attackRange = 3.0;
    public static double searchRadius = 40.0;   // how far it looks for mobs
    public static double pickupRadius = 25.0;   // how far it looks for drops

    public static void stopAll() { autoFish = false; autoSlayer = false; }

    private static File file() {
        return new File(Minecraft.getMinecraft().mcDataDir, "config/fpauto.properties");
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("autoHeal", String.valueOf(autoHeal));
        p.setProperty("autoPickup", String.valueOf(autoPickup));
        p.setProperty("showPath", String.valueOf(showPath));
        p.setProperty("showHud", String.valueOf(showHud));
        p.setProperty("presetIndex", String.valueOf(presetIndex));
        p.setProperty("targets", targets);
        p.setProperty("pickupItems", pickupItems);
        p.setProperty("healPercent", String.valueOf(healPercent));
        p.setProperty("searchRadius", String.valueOf(searchRadius));
        p.setProperty("weaponSlot", String.valueOf(weaponSlot));
        p.setProperty("healSlot", String.valueOf(healSlot));
        p.setProperty("rodSlot", String.valueOf(rodSlot));
        try {
            File f = file();
            f.getParentFile().mkdirs();
            FileOutputStream o = new FileOutputStream(f);
            p.store(o, "FPAuto");
            o.close();
        } catch (IOException ignored) {}
    }

    public static void load() {
        File f = file();
        if (!f.exists()) return;
        Properties p = new Properties();
        try {
            FileInputStream i = new FileInputStream(f);
            p.load(i);
            i.close();
            autoHeal = Boolean.parseBoolean(p.getProperty("autoHeal", "true"));
            autoPickup = Boolean.parseBoolean(p.getProperty("autoPickup", "true"));
            showPath = Boolean.parseBoolean(p.getProperty("showPath", "true"));
            showHud = Boolean.parseBoolean(p.getProperty("showHud", "true"));
            presetIndex = Integer.parseInt(p.getProperty("presetIndex", "0"));
            if (presetIndex < 0 || presetIndex >= PRESET_NAMES.length) presetIndex = 0;
            targets = p.getProperty("targets", targets);
            pickupItems = p.getProperty("pickupItems", pickupItems);
            healPercent = Float.parseFloat(p.getProperty("healPercent", "0.5"));
            searchRadius = Double.parseDouble(p.getProperty("searchRadius", "40"));
            weaponSlot = Integer.parseInt(p.getProperty("weaponSlot", "0"));
            healSlot = Integer.parseInt(p.getProperty("healSlot", "1"));
            rodSlot = Integer.parseInt(p.getProperty("rodSlot", "2"));
        } catch (Exception ignored) {}
    }
}
