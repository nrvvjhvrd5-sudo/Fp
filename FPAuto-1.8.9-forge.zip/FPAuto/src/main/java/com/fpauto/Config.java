package com.fpauto;

public class Config {
    public static boolean autoFish = false;
    public static boolean autoSlayer = false;
    public static boolean autoHeal = true;

    public static int slayerType = 0;
    public static final String[] SLAYER_LABELS = {
        "Revenant (Zombie)", "Tarantula (Spider)", "Sven (Wolf)",
        "Voidgloom (Enderman)", "Inferno (Blaze)", "Riftstalker (Vampire)", "Custom"
    };
    // index 0 = boss name (priority), rest = minion/mob keywords
    public static final String[][] SLAYER_KEYWORDS = {
        {"Revenant Horror", "Zombie"},
        {"Tarantula Broodfather", "Spider"},
        {"Sven Packmaster", "Wolf"},
        {"Voidgloom Seraph", "Enderman", "Zealot"},
        {"Inferno Demonlord", "Blaze"},
        {"Riftstalker Bloodfiend", "Vampire"},
        {"CustomBossName", "CustomMob"}   // edit for the 7th / any other slayer
    };

    public static float healPercent = 0.5f;
    public static int weaponSlot = 0;   // hotbar 0-8
    public static int healSlot = 1;
    public static int rodSlot = 2;

    public static int recastDelay = 12;      // ticks
    public static int attackDelay = 4;       // ticks between swings
    public static double attackRange = 3.0;
    public static double searchRadius = 20.0;

    public static void stopAll() { autoFish = false; autoSlayer = false; }
}
