package com.fpauto;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockPos;
import net.minecraft.util.Vec3;
import net.minecraft.world.World;

import java.util.*;

/** Simple A* over walkable block columns: walk, jump up 1, drop up to 3, diagonals. */
public class Pathfinder {

    private static final int[][] DIRS = {
        {1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}
    };

    private static class Node {
        final BlockPos pos; final double g, f; final Node parent;
        Node(BlockPos pos, double g, double f, Node parent) {
            this.pos = pos; this.g = g; this.f = f; this.parent = parent;
        }
    }

    public static List<BlockPos> find(World w, BlockPos start, Vec3 goal,
                                      double goalH, double goalV, double maxRange, int maxNodes) {
        return new Search(w, start, goal, goalH, goalV, maxRange).run(maxNodes);
    }

    private static class Search {
        final World w; final BlockPos start; final Vec3 goal;
        final double goalH, goalV, maxRange;
        final PriorityQueue<Node> open = new PriorityQueue<Node>(256, new Comparator<Node>() {
            public int compare(Node a, Node b) { return Double.compare(a.f, b.f); }
        });
        final Map<Long, Double> best = new HashMap<Long, Double>();
        final Set<Long> closed = new HashSet<Long>();

        Search(World w, BlockPos start, Vec3 goal, double goalH, double goalV, double maxRange) {
            this.w = w; this.start = start; this.goal = goal;
            this.goalH = goalH; this.goalV = goalV; this.maxRange = maxRange;
        }

        List<BlockPos> run(int maxNodes) {
            open.add(new Node(start, 0, h(start), null));
            best.put(start.toLong(), 0.0);
            int n = 0;
            while (!open.isEmpty() && n < maxNodes) {
                Node cur = open.poll();
                if (!closed.add(cur.pos.toLong())) continue;
                n++;
                if (isGoal(cur.pos)) return build(cur);
                expand(cur);
            }
            return null;
        }

        void expand(Node cur) {
            BlockPos p = cur.pos;
            for (int[] d : DIRS) {
                int dx = d[0], dz = d[1];
                boolean diag = dx != 0 && dz != 0;
                BlockPos c = p.add(dx, 0, dz);
                if (diag) {
                    if (passable(p.add(dx, 0, 0)) && passable(p.add(dx, 1, 0))
                            && passable(p.add(0, 0, dz)) && passable(p.add(0, 1, dz))
                            && standable(c)) push(cur, c, 1.414);
                    continue;
                }
                if (standable(c)) {
                    push(cur, c, 1.0);
                } else if (!passable(c) || !passable(c.up())) {
                    BlockPos u = p.add(dx, 1, dz);                 // step / jump up one block
                    if (passable(p.up(2)) && standable(u)) push(cur, u, 2.0);
                } else {                                           // drop down up to 3
                    for (int k = 1; k <= 3; k++) {
                        BlockPos dn = c.down(k);
                        if (standable(dn)) { push(cur, dn, 1.0 + 0.3 * k); break; }
                        if (!passable(dn)) break;
                    }
                }
            }
        }

        void push(Node cur, BlockPos c, double cost) {
            double dx = c.getX() - start.getX(), dz = c.getZ() - start.getZ();
            if (Math.sqrt(dx * dx + dz * dz) > maxRange) return;
            double g = cur.g + cost;
            Double old = best.get(c.toLong());
            if (old != null && old <= g) return;
            best.put(c.toLong(), g);
            open.add(new Node(c, g, g + h(c), cur));
        }

        double h(BlockPos c) {
            double dx = c.getX() + 0.5 - goal.xCoord, dy = c.getY() - goal.yCoord, dz = c.getZ() + 0.5 - goal.zCoord;
            return Math.sqrt(dx * dx + dy * dy + dz * dz);
        }

        boolean isGoal(BlockPos c) {
            double dx = c.getX() + 0.5 - goal.xCoord, dz = c.getZ() + 0.5 - goal.zCoord;
            return Math.sqrt(dx * dx + dz * dz) <= goalH && Math.abs(c.getY() - goal.yCoord) <= goalV;
        }

        List<BlockPos> build(Node end) {
            LinkedList<BlockPos> out = new LinkedList<BlockPos>();
            for (Node n = end; n != null; n = n.parent) out.addFirst(n.pos);
            return new ArrayList<BlockPos>(out);
        }

        boolean passable(BlockPos pos) {
            IBlockState s = w.getBlockState(pos);
            Block b = s.getBlock();
            if (b.getMaterial().isLiquid()) return false;
            if (b == Blocks.fire || b == Blocks.cactus || b == Blocks.web) return false;
            return b.getCollisionBoundingBox(w, pos, s) == null;
        }

        boolean standable(BlockPos pos) {
            if (!passable(pos) || !passable(pos.up())) return false;
            BlockPos fl = pos.down();
            IBlockState s = w.getBlockState(fl);
            Block b = s.getBlock();
            if (b.getMaterial().isLiquid() || b == Blocks.cactus || b == Blocks.fire) return false;
            return b.getCollisionBoundingBox(w, fl, s) != null;
        }
    }
}
