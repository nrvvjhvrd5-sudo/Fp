package com.fpauto;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AutoSlayer {
    private static int tick = 0;
    private static int attackCd = 0;
    private static int healState = 0, healTimer = 0, healCooldown = 0, savedSlot = 0;
    private static boolean wasActive = false;

    public static Entity target;
    public static EntityItem itemTarget;
    public static List<BlockPos> path;
    private static int pathIdx = 0, pathTick = -100;
    private static Vec3 pathGoal;
    private static int noPathTicks = 0;

    private static double lastX, lastZ;
    private static int stuckTimer = 0, stuckCount = 0;
    private static final Map<Integer, Integer> blacklist = new HashMap<Integer, Integer>();

    public static int kills = 0, pickups = 0;
    public static String status = "Off";

    public static void tick(Minecraft mc) {
        if (!Config.autoSlayer) {
            if (wasActive) { release(mc); clearNav(); target = null; itemTarget = null; wasActive = false; status = "Off"; }
            return;
        }
        wasActive = true;
        tick++;
        EntityPlayer p = mc.thePlayer;
        if (attackCd > 0) attackCd--;
        if (healCooldown > 0) healCooldown--;

        if (handleHeal(mc, p)) { status = "Healing"; return; }

        // count kills / pickups
        if (target != null && (target.isDead || (target instanceof EntityLivingBase && ((EntityLivingBase) target).getHealth() <= 0))) {
            kills++; target = null; clearNav();
        }
        if (itemTarget != null && itemTarget.isDead) {
            if (p.getDistanceToEntity(itemTarget) < 3.5) pickups++;
            itemTarget = null; clearNav();
        }

        EntityItem item = Config.autoPickup ? findItem(mc, p) : null;
        Entity mob = findTarget(mc, p);
        target = mob;
        if (item != itemTarget) { itemTarget = item; clearNav(); }

        boolean mobClose = mob != null && p.getDistanceToEntity(mob) <= Config.attackRange + 1.5;

        if (itemTarget != null && !mobClose) {
            status = "Picking up item";
            p.inventory.currentItem = Config.weaponSlot;
            goTo(mc, p, itemTarget, 0.9, 1.5, itemTarget.getEntityId());
            return;
        }
        if (mob == null) {
            release(mc); clearNav(); status = "Searching (no target in range)";
            return;
        }

        p.inventory.currentItem = Config.weaponSlot;
        double dist = p.getDistanceToEntity(mob);
        if (dist <= Config.attackRange) {
            release(mc); clearNav();
            aimAt(p, mob);
            status = "Attacking";
            if (attackCd == 0) {
                mc.playerController.attackEntity(p, mob);
                p.swingItem();
                attackCd = Config.attackDelay;
            }
        } else {
            status = "Moving to target";
            goTo(mc, p, mob, Math.max(1.0, Config.attackRange - 0.8), 3.0, mob.getEntityId());
        }
    }

    // ---------------- navigation ----------------

    private static void goTo(Minecraft mc, EntityPlayer p, Entity e, double goalH, double goalV, int id) {
        Vec3 goal = new Vec3(e.posX, e.posY, e.posZ);
        boolean need = path == null || pathGoal == null || tick - pathTick > 15
                || pathGoal.distanceTo(goal) > 2.5 || pathIdx >= path.size();
        if (need) {
            BlockPos start = new BlockPos(Math.floor(p.posX), Math.floor(p.posY + 0.01), Math.floor(p.posZ));
            path = Pathfinder.find(mc.theWorld, start, goal, goalH, goalV, Config.searchRadius + 10, 5000);
            pathIdx = 0; pathTick = tick; pathGoal = goal;
            if (path == null) noPathTicks += 15; else noPathTicks = 0;
            if (noPathTicks >= 60) { blacklist.put(id, tick + 300); noPathTicks = 0; clearNav(); return; }
        }

        double tx, tz;
        boolean needJump = false;
        if (path == null || path.size() <= 1) {            // fallback: walk straight
            tx = e.posX; tz = e.posZ;
        } else {
            while (pathIdx < path.size() - 1 && near(p, path.get(pathIdx))) pathIdx++;
            BlockPos n = path.get(Math.min(pathIdx, path.size() - 1));
            tx = n.getX() + 0.5; tz = n.getZ() + 0.5;
            if (n.getY() > Math.floor(p.posY + 0.01)) needJump = true;
        }
        faceXZ(p, tx, tz);

        KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), true);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), true);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(),
                p.onGround && (needJump || p.isCollidedHorizontally));

        // stuck detection
        if (++stuckTimer >= 30) {
            double moved = Math.hypot(p.posX - lastX, p.posZ - lastZ);
            lastX = p.posX; lastZ = p.posZ; stuckTimer = 0;
            if (moved < 0.6) {
                path = null; stuckCount++;
                if (stuckCount >= 4) { blacklist.put(id, tick + 300); stuckCount = 0; clearNav(); }
            } else stuckCount = 0;
        }
    }

    private static boolean near(EntityPlayer p, BlockPos n) {
        return Math.hypot(p.posX - (n.getX() + 0.5), p.posZ - (n.getZ() + 0.5)) < 0.7
                && Math.abs(p.posY - n.getY()) < 1.5;
    }

    private static void clearNav() { path = null; pathIdx = 0; pathGoal = null; noPathTicks = 0; stuckTimer = 0; }

    private static void faceXZ(EntityPlayer p, double x, double z) {
        p.rotationYaw = (float) (Math.atan2(z - p.posZ, x - p.posX) * 180.0 / Math.PI) - 90f;
        p.rotationPitch = 0f;
    }

    private static void aimAt(EntityPlayer p, Entity t) {
        double dx = t.posX - p.posX, dz = t.posZ - p.posZ;
        double dy = (t.posY + t.getEyeHeight() * 0.8) - (p.posY + p.getEyeHeight());
        p.rotationYaw = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
        p.rotationPitch = MathHelper.clamp_float(
                (float) -(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI), -90f, 90f);
    }

    // ---------------- targeting ----------------

    private static String clean(String s) {
        String r = EnumChatFormatting.getTextWithoutFormattingCodes(s);
        return r == null ? "" : r.toLowerCase();
    }

    private static List<String> keywords(String csv) {
        List<String> out = new ArrayList<String>();
        for (String part : csv.split(",")) {
            String t = part.trim().toLowerCase();
            if (!t.isEmpty()) out.add(t);
        }
        return out;
    }

    private static boolean blacklisted(int id) {
        Integer until = blacklist.get(id);
        return until != null && until > tick;
    }

    private static Entity findTarget(Minecraft mc, EntityPlayer p) {
        List<String> kw = keywords(Config.targets);
        if (kw.isEmpty()) return null;

        List<Entity> all = mc.theWorld.loadedEntityList;
        List<Entity> stands = new ArrayList<Entity>();
        for (Entity e : all)
            if (e instanceof EntityArmorStand && e.hasCustomName()
                    && p.getDistanceToEntity(e) <= Config.searchRadius + 5) stands.add(e);

        Entity best = null; double bestScore = Double.MAX_VALUE;
        for (Entity e : all) {
            if (!(e instanceof EntityLivingBase) || e instanceof EntityArmorStand
                    || e instanceof EntityPlayer || e == p) continue;
            if (e.isDead || ((EntityLivingBase) e).getHealth() <= 0) continue;
            double d = p.getDistanceToEntity(e);
            if (d > Config.searchRadius || blacklisted(e.getEntityId())) continue;

            StringBuilder names = new StringBuilder(clean(e.getName()));
            for (Entity s : stands) {
                double dx = Math.abs(s.posX - e.posX), dz = Math.abs(s.posZ - e.posZ);
                double dy = s.posY - e.posY;
                if (dx <= 1.5 && dz <= 1.5 && dy >= -1 && dy <= 4)
                    names.append('|').append(clean(s.getCustomNameTag()));
            }
            String text = names.toString();
            int prio = -1;
            for (int i = 0; i < kw.size(); i++)
                if (text.contains(kw.get(i))) { prio = i; break; }
            if (prio < 0) continue;

            double score = prio * 1000.0 + d - (e == target ? 4 : 0);
            if (score < bestScore) { bestScore = score; best = e; }
        }
        return best;
    }

    private static EntityItem findItem(Minecraft mc, EntityPlayer p) {
        List<String> kw = keywords(Config.pickupItems);
        if (kw.isEmpty()) return null;
        EntityItem best = null; double bd = Double.MAX_VALUE;
        for (Entity e : mc.theWorld.loadedEntityList) {
            if (!(e instanceof EntityItem) || e.isDead || blacklisted(e.getEntityId())) continue;
            EntityItem it = (EntityItem) e;
            if (it.getEntityItem() == null) continue;
            double d = p.getDistanceToEntity(e);
            if (d > Config.pickupRadius) continue;
            String name = clean(it.getEntityItem().getDisplayName());
            boolean ok = false;
            for (String k : kw) if (name.contains(k)) { ok = true; break; }
            if (ok && d < bd) { bd = d; best = it; }
        }
        return best;
    }

    // ---------------- healing ----------------

    private static boolean handleHeal(Minecraft mc, EntityPlayer p) {
        if (healState == 0) {
            if (Config.autoHeal && healCooldown == 0
                    && p.getHealth() / p.getMaxHealth() < Config.healPercent) {
                release(mc);
                savedSlot = p.inventory.currentItem;
                p.inventory.currentItem = Config.healSlot;
                healState = 1; healTimer = 2;
                return true;
            }
            return false;
        }
        if (--healTimer > 0) return true;
        if (healState == 1) {
            mc.playerController.sendUseItem(p, mc.theWorld, p.getHeldItem());
            p.swingItem();
            healState = 2; healTimer = 3;
            return true;
        }
        p.inventory.currentItem = savedSlot;
        healState = 0; healCooldown = 40;
        return true;
    }

    public static void release(Minecraft mc) {
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), false);
    }
}
