package com.fpauto;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumChatFormatting;
import net.minecraft.util.MathHelper;

import java.util.List;

public class AutoSlayer {
    private static int attackCd = 0;
    private static int healState = 0;   // 0 idle, 1 switched, 2 used
    private static int healTimer = 0;
    private static int healCooldown = 0;
    private static int savedSlot = 0;
    private static boolean wasActive = false;

    public static void tick(Minecraft mc) {
        if (!Config.autoSlayer) {
            if (wasActive) { release(mc); wasActive = false; }
            return;
        }
        wasActive = true;
        EntityPlayer p = mc.thePlayer;
        if (attackCd > 0) attackCd--;
        if (healCooldown > 0) healCooldown--;

        if (handleHeal(mc, p)) return;

        Entity target = findTarget(mc, p);
        if (target == null) { release(mc); return; }

        // aim
        double dx = target.posX - p.posX;
        double dz = target.posZ - p.posZ;
        double dy = (target.posY + target.getEyeHeight() * 0.8) - (p.posY + p.getEyeHeight());
        float yaw = (float) (Math.atan2(dz, dx) * 180.0 / Math.PI) - 90f;
        float pitch = (float) -(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * 180.0 / Math.PI);
        p.rotationYaw = yaw;
        p.rotationPitch = MathHelper.clamp_float(pitch, -90f, 90f);

        p.inventory.currentItem = Config.weaponSlot;

        double dist = p.getDistanceToEntity(target);
        if (dist > Config.attackRange) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), true);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), true);
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), p.isCollidedHorizontally);
        } else {
            release(mc);
            if (attackCd == 0) {
                mc.playerController.attackEntity(p, target);
                p.swingItem();
                attackCd = Config.attackDelay;
            }
        }
    }

    /** returns true while a heal sequence is running */
    private static boolean handleHeal(Minecraft mc, EntityPlayer p) {
        if (healState == 0) {
            if (Config.autoHeal && healCooldown == 0
                    && p.getHealth() / p.getMaxHealth() < Config.healPercent) {
                release(mc);
                savedSlot = p.inventory.currentItem;
                p.inventory.currentItem = Config.healSlot;
                healState = 1; healTimer = 2;
                return true;
            }
            return false;
        }
        if (--healTimer > 0) return true;
        if (healState == 1) {
            mc.playerController.sendUseItem(p, mc.theWorld, p.getHeldItem());
            p.swingItem();
            healState = 2; healTimer = 3;
            return true;
        }
        p.inventory.currentItem = savedSlot;   // state 2: restore
        healState = 0; healCooldown = 40;
        return true;
    }

    private static Entity findTarget(Minecraft mc, EntityPlayer p) {
        String[] kw = Config.SLAYER_KEYWORDS[Config.slayerType];
        Entity best = null; double bestScore = Double.MAX_VALUE;

        List<Entity> all = mc.theWorld.loadedEntityList;
        for (Entity stand : all) {
            if (!(stand instanceof EntityArmorStand) || !stand.hasCustomName()) continue;
            String name = EnumChatFormatting.getTextWithoutFormattingCodes(stand.getCustomNameTag());
            if (name == null) continue;
            int prio = -1;
            for (int i = 0; i < kw.length; i++)
                if (name.contains(kw[i])) { prio = (i == 0) ? 0 : 1; break; }
            if (prio < 0) continue;
            if (p.getDistanceToEntity(stand) > Config.searchRadius) continue;

            Entity mob = mobUnder(all, stand);
            if (mob == null || mob.isDead) continue;
            double score = p.getDistanceToEntity(mob) + prio * 1000.0;  // boss first
            if (score < bestScore) { bestScore = score; best = mob; }
        }
        return best;
    }

    private static Entity mobUnder(List<Entity> all, Entity stand) {
        Entity best = null; double bd = Double.MAX_VALUE;
        for (Entity e : all) {
            if (!(e instanceof EntityLivingBase) || e instanceof EntityArmorStand
                    || e instanceof EntityPlayer) continue;
            double dx = e.posX - stand.posX, dz = e.posZ - stand.posZ;
            double dy = stand.posY - e.posY;
            if (Math.abs(dx) > 1.5 || Math.abs(dz) > 1.5 || dy < -1 || dy > 4) continue;
            double d = dx * dx + dz * dz + dy * dy;
            if (d < bd) { bd = d; best = e; }
        }
        return best;
    }

    public static void release(Minecraft mc) {
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindSprint.getKeyCode(), false);
        KeyBinding.setKeyBindState(mc.gameSettings.keyBindJump.getKeyCode(), false);
    }
}
