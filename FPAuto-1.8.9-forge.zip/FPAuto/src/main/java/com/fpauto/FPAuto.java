package com.fpauto;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

@Mod(modid = "fpauto", name = "FPAuto", version = "1.0", clientSideOnly = true, acceptedMinecraftVersions = "[1.8.9]")
public class FPAuto {
    private final KeyBinding openGui = new KeyBinding("Open GUI", Keyboard.KEY_RSHIFT, "FPAuto");
    private final KeyBinding stopAll = new KeyBinding("Stop everything", Keyboard.KEY_K, "FPAuto");

    @EventHandler
    public void init(FMLInitializationEvent e) {
        ClientRegistry.registerKeyBinding(openGui);
        ClientRegistry.registerKeyBinding(stopAll);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent ev) {
        if (ev.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || mc.theWorld == null) return;

        if (openGui.isPressed()) mc.displayGuiScreen(new ConfigGui());
        if (stopAll.isPressed()) Config.stopAll();

        if (mc.currentScreen == null) {
            AutoFish.tick(mc);
            AutoSlayer.tick(mc);
        } else {
            AutoSlayer.release(mc);
        }
    }
}
