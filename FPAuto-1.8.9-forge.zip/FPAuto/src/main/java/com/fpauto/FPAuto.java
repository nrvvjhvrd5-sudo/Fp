package com.fpauto;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.BlockPos;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.util.List;

@Mod(modid = "fpauto", name = "FPAuto", version = "1.1", clientSideOnly = true, acceptedMinecraftVersions = "[1.8.9]")
public class FPAuto {
    private final KeyBinding openGui = new KeyBinding("Open GUI", Keyboard.KEY_RSHIFT, "FPAuto");
    private final KeyBinding stopAll = new KeyBinding("Stop everything", Keyboard.KEY_K, "FPAuto");
    private final KeyBinding toggleSlayer = new KeyBinding("Toggle Auto Slayer", Keyboard.KEY_G, "FPAuto");

    @EventHandler
    public void init(FMLInitializationEvent e) {
        Config.load();
        ClientRegistry.registerKeyBinding(openGui);
        ClientRegistry.registerKeyBinding(stopAll);
        ClientRegistry.registerKeyBinding(toggleSlayer);
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent ev) {
        if (ev.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || mc.theWorld == null) return;

        if (openGui.isPressed()) mc.displayGuiScreen(new ConfigGui());
        if (stopAll.isPressed()) Config.stopAll();
        if (toggleSlayer.isPressed()) {
            Config.autoSlayer = !Config.autoSlayer;
            if (Config.autoSlayer) Config.autoFish = false;
        }

        if (mc.currentScreen == null) {
            AutoFish.tick(mc);
            AutoSlayer.tick(mc);
        } else {
            AutoSlayer.release(mc);
        }
    }

    @SubscribeEvent
    public void onRender(RenderWorldLastEvent ev) {
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayer p = mc.thePlayer;
        if (p == null || !Config.showPath || !Config.autoSlayer) return;
        List<BlockPos> path = AutoSlayer.path;
        if (path == null || path.size() < 2) return;

        double px = p.lastTickPosX + (p.posX - p.lastTickPosX) * ev.partialTicks;
        double py = p.lastTickPosY + (p.posY - p.lastTickPosY) * ev.partialTicks;
        double pz = p.lastTickPosZ + (p.posZ - p.lastTickPosZ) * ev.partialTicks;

        GlStateManager.pushMatrix();
        GlStateManager.disableTexture2D();
        GlStateManager.disableDepth();
        GlStateManager.disableLighting();
        GL11.glLineWidth(2.5f);
        GlStateManager.color(0.2f, 1f, 0.4f, 1f);
        GL11.glBegin(GL11.GL_LINE_STRIP);
        for (BlockPos n : path)
            GL11.glVertex3d(n.getX() + 0.5 - px, n.getY() + 0.1 - py, n.getZ() + 0.5 - pz);
        GL11.glEnd();
        GlStateManager.color(1f, 1f, 1f, 1f);
        GlStateManager.enableDepth();
        GlStateManager.enableTexture2D();
        GlStateManager.popMatrix();
    }

    @SubscribeEvent
    public void onText(RenderGameOverlayEvent.Text ev) {
        Minecraft mc = Minecraft.getMinecraft();
        if (!Config.showHud || mc.thePlayer == null || !(Config.autoSlayer || Config.autoFish)) return;
        int y = 4;
        mc.fontRendererObj.drawStringWithShadow("FPAuto: " + (Config.autoFish ? "Fishing" : AutoSlayer.status), 4, y, 0x55FF55);
        if (Config.autoSlayer) {
            y += 10;
            mc.fontRendererObj.drawStringWithShadow("Kills: " + AutoSlayer.kills + "   Pickups: " + AutoSlayer.pickups, 4, y, 0xFFFFFF);
            if (AutoSlayer.target != null) {
                y += 10;
                mc.fontRendererObj.drawStringWithShadow("Target: " + AutoSlayer.target.getName()
                        + " (" + (int) mc.thePlayer.getDistanceToEntity(AutoSlayer.target) + "m)", 4, y, 0xFFFF55);
            }
            if (AutoSlayer.path != null) {
                y += 10;
                mc.fontRendererObj.drawStringWithShadow("Path nodes: " + AutoSlayer.path.size(), 4, y, 0xAAAAAA);
            }
        }
    }
}
