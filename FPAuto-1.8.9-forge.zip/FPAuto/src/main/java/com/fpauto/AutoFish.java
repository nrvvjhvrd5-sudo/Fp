package com.fpauto;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.item.ItemFishingRod;
import net.minecraft.item.ItemStack;

public class AutoFish {
    private static int cooldown = 0;

    public static void tick(Minecraft mc) {
        if (!Config.autoFish) return;
        if (cooldown > 0) { cooldown--; return; }

        ItemStack held = mc.thePlayer.getHeldItem();
        if (held == null || !(held.getItem() instanceof ItemFishingRod)) {
            mc.thePlayer.inventory.currentItem = Config.rodSlot;
            cooldown = 2;
            return;
        }

        EntityFishHook hook = mc.thePlayer.fishEntity;
        if (hook == null) {                       // cast
            use(mc, held);
            cooldown = Config.recastDelay;
            return;
        }
        // bite: bobber dips sharply after settling in water
        if (hook.ticksExisted > 20 && hook.isInWater() && hook.motionY < -0.15) {
            use(mc, held);                        // reel in
            cooldown = Config.recastDelay;
        }
    }

    private static void use(Minecraft mc, ItemStack held) {
        mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld, held);
        mc.thePlayer.swingItem();
    }
}
