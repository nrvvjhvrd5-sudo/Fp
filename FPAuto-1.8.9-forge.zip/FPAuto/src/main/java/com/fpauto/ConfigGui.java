package com.fpauto;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiTextField;
import org.lwjgl.input.Keyboard;

import java.io.IOException;

public class ConfigGui extends GuiScreen {
    private GuiTextField targets, items;
    private GuiButton fish, slayer, heal, pickup, path, hud, healPct, radius, preset;

    @Override
    public void initGui() {
        Keyboard.enableRepeatEvents(true);
        buttonList.clear();
        int cx = width / 2, y = height / 2 - 112;
        int L = cx - 155, R = cx + 5;

        buttonList.add(fish   = new GuiButton(0, L, y,      150, 20, ""));
        buttonList.add(slayer = new GuiButton(1, R, y,      150, 20, ""));
        buttonList.add(heal   = new GuiButton(2, L, y + 24, 150, 20, ""));
        buttonList.add(pickup = new GuiButton(3, R, y + 24, 150, 20, ""));
        buttonList.add(path   = new GuiButton(4, L, y + 48, 150, 20, ""));
        buttonList.add(hud    = new GuiButton(5, R, y + 48, 150, 20, ""));

        buttonList.add(new GuiButton(10, L, y + 72, 20, 20, "-"));
        buttonList.add(healPct = new GuiButton(11, L + 22, y + 72, 106, 20, ""));
        buttonList.add(new GuiButton(12, L + 130, y + 72, 20, 20, "+"));

        buttonList.add(new GuiButton(20, R, y + 72, 20, 20, "-"));
        buttonList.add(radius = new GuiButton(21, R + 22, y + 72, 106, 20, ""));
        buttonList.add(new GuiButton(22, R + 130, y + 72, 20, 20, "+"));

        buttonList.add(preset = new GuiButton(30, L, y + 96, 310, 20, ""));

        targets = new GuiTextField(100, fontRendererObj, L, y + 132, 310, 20);
        targets.setMaxStringLength(200);
        targets.setText(Config.targets);
        items = new GuiTextField(101, fontRendererObj, L, y + 170, 310, 20);
        items.setMaxStringLength(200);
        items.setText(Config.pickupItems);

        buttonList.add(new GuiButton(99, L, y + 196, 310, 20, "Done"));
        refresh();
    }

    private void refresh() {
        fish.displayString = "Auto Fishing: " + onOff(Config.autoFish);
        slayer.displayString = "Auto Slayer: " + onOff(Config.autoSlayer);
        heal.displayString = "Auto Heal: " + onOff(Config.autoHeal);
        pickup.displayString = "Pick up drops: " + onOff(Config.autoPickup);
        path.displayString = "Show path: " + onOff(Config.showPath);
        hud.displayString = "Show HUD: " + onOff(Config.showHud);
        healPct.displayString = "Heal <" + (int) (Config.healPercent * 100) + "%";
        radius.displayString = "Range " + (int) Config.searchRadius;
        preset.displayString = "Preset: " + Config.PRESET_NAMES[Config.presetIndex] + "  (click to change)";
    }

    private String onOff(boolean b) { return b ? "ON" : "OFF"; }

    @Override
    protected void actionPerformed(GuiButton b) {
        switch (b.id) {
            case 0: Config.autoFish = !Config.autoFish; if (Config.autoFish) Config.autoSlayer = false; break;
            case 1: Config.autoSlayer = !Config.autoSlayer; if (Config.autoSlayer) Config.autoFish = false; break;
            case 2: Config.autoHeal = !Config.autoHeal; break;
            case 3: Config.autoPickup = !Config.autoPickup; break;
            case 4: Config.showPath = !Config.showPath; break;
            case 5: Config.showHud = !Config.showHud; break;
            case 10: Config.healPercent = Math.max(0.1f, Config.healPercent - 0.05f); break;
            case 12: Config.healPercent = Math.min(0.95f, Config.healPercent + 0.05f); break;
            case 20: Config.searchRadius = Math.max(8, Config.searchRadius - 4); break;
            case 22: Config.searchRadius = Math.min(100, Config.searchRadius + 4); break;
            case 30:
                Config.presetIndex = (Config.presetIndex + 1) % Config.PRESET_NAMES.length;
                String t = Config.PRESET_TARGETS[Config.presetIndex];
                if (!t.isEmpty()) { Config.targets = t; targets.setText(t); }
                break;
            case 99: mc.displayGuiScreen(null); return;
        }
        refresh();
    }

    @Override
    protected void keyTyped(char c, int k) throws IOException {
        if (targets.textboxKeyTyped(c, k)) { Config.targets = targets.getText(); return; }
        if (items.textboxKeyTyped(c, k)) { Config.pickupItems = items.getText(); return; }
        super.keyTyped(c, k);
    }

    @Override
    protected void mouseClicked(int x, int y, int btn) throws IOException {
        targets.mouseClicked(x, y, btn);
        items.mouseClicked(x, y, btn);
        super.mouseClicked(x, y, btn);
    }

    @Override
    public void updateScreen() { targets.updateCursorCounter(); items.updateCursorCounter(); }

    @Override
    public void onGuiClosed() { Keyboard.enableRepeatEvents(false); Config.save(); }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawDefaultBackground();
        int cx = width / 2, y = height / 2 - 112;
        drawCenteredString(fontRendererObj, "FPAuto", cx, y - 14, 0xFFFFFF);
        drawString(fontRendererObj, "Targets (comma separated, left = highest priority)", cx - 155, y + 120, 0xAAAAAA);
        drawString(fontRendererObj, "Pick up these drops (comma separated)", cx - 155, y + 158, 0xAAAAAA);
        targets.drawTextBox();
        items.drawTextBox();
        super.drawScreen(mx, my, pt);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
