package com.fpauto;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;

public class ConfigGui extends GuiScreen {
    private GuiButton fish, slayer, heal, type, healPct;

    @Override
    public void initGui() {
        buttonList.clear();
        int x = width / 2 - 100, y = height / 2 - 70;
        buttonList.add(fish    = new GuiButton(0, x, y,       200, 20, ""));
        buttonList.add(slayer  = new GuiButton(1, x, y + 24,  200, 20, ""));
        buttonList.add(heal    = new GuiButton(2, x, y + 48,  200, 20, ""));
        buttonList.add(type    = new GuiButton(3, x, y + 72,  200, 20, ""));
        buttonList.add(new GuiButton(4, x, y + 96, 20, 20, "-"));
        buttonList.add(healPct = new GuiButton(5, x + 24, y + 96, 152, 20, ""));
        buttonList.add(new GuiButton(6, x + 180, y + 96, 20, 20, "+"));
        buttonList.add(new GuiButton(7, x, y + 124, 200, 20, "Done"));
        refresh();
    }

    private void refresh() {
        fish.displayString = "Auto Fishing: " + (Config.autoFish ? "ON" : "OFF");
        slayer.displayString = "Auto Slayer: " + (Config.autoSlayer ? "ON" : "OFF");
        heal.displayString = "Auto Heal: " + (Config.autoHeal ? "ON" : "OFF");
        type.displayString = "Slayer: " + Config.SLAYER_LABELS[Config.slayerType];
        healPct.displayString = "Heal below " + (int) (Config.healPercent * 100) + "% HP";
    }

    @Override
    protected void actionPerformed(GuiButton b) {
        switch (b.id) {
            case 0: Config.autoFish = !Config.autoFish; if (Config.autoFish) Config.autoSlayer = false; break;
            case 1: Config.autoSlayer = !Config.autoSlayer; if (Config.autoSlayer) Config.autoFish = false; break;
            case 2: Config.autoHeal = !Config.autoHeal; break;
            case 3: Config.slayerType = (Config.slayerType + 1) % Config.SLAYER_LABELS.length; break;
            case 4: Config.healPercent = Math.max(0.1f, Config.healPercent - 0.05f); break;
            case 6: Config.healPercent = Math.min(0.95f, Config.healPercent + 0.05f); break;
            case 7: mc.displayGuiScreen(null); return;
        }
        refresh();
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawDefaultBackground();
        drawCenteredString(fontRendererObj, "FPAuto", width / 2, height / 2 - 95, 0xFFFFFF);
        super.drawScreen(mx, my, pt);
    }

    @Override
    public boolean doesGuiPauseGame() { return false; }
}
